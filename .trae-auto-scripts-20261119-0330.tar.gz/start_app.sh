#!/bin/bash
# Trae 中国版 · 沙箱持久化启动脚本
# 用法: bash /workspace/.trae-auto/start_app.sh [--with-browser]
set -u
BASE=/workspace/.trae-auto
APP=$BASE/app/usr/share/trae-cn/trae-cn
export DISPLAY=:98
export XDG_RUNTIME_DIR=/tmp/xdg
mkdir -p "$XDG_RUNTIME_DIR" "$BASE/logs" "$BASE/userdata"
chmod 700 "$XDG_RUNTIME_DIR" 2>/dev/null

# 1) 系统依赖（rootfs 每轮重置，仅首次缺失时安装）
if [ ! -x /usr/bin/Xvfb ] || [ ! -f /usr/lib/x86_64-linux-gnu/libgtk-3.so.0 ]; then
  echo "[deps] installing system packages..."
  apt-get -qq update >/dev/null 2>&1
  DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    xvfb xdotool libgtk-3-0t64 libnss3 libnspr4 libasound2t64 libatk1.0-0t64 \
    libatk-bridge2.0-0t64 libatspi2.0-0t64 libcups2t64 libgbm1 libxkbcommon0 \
    libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libx11-6 libxcb1 libxext6 \
    libcairo2 libpango-1.0-0 libglib2.0-0t64 libdbus-1-3 libcurl4 libexpat1 \
    libstdc++6 libudev1 libxkbfile1 xdg-utils ca-certificates \
    >/dev/null 2>&1 || echo "[deps] WARN: some packages failed"
fi

# 2) Xvfb
if ! pgrep -f "Xvfb :98" >/dev/null; then
  setsid nohup Xvfb :98 -screen 0 1600x1000x24 -nolisten tcp >"$BASE/logs/xvfb.log" 2>&1 </dev/null &
  sleep 2
fi

# 3) Trae 主程序（干净环境，登录态持久到 /workspace）
if ! curl -s --noproxy '*' --max-time 2 http://127.0.0.1:9334/json/version >/dev/null; then
  setsid nohup env -i HOME=/root USER=root DISPLAY=:98 XDG_RUNTIME_DIR=/tmp/xdg \
    PATH=/usr/local/bin:/usr/bin:/bin LANG=zh_CN.UTF-8 \
    HTTP_PROXY=http://127.0.0.1:18080 HTTPS_PROXY=http://127.0.0.1:18080 \
    http_proxy=http://127.0.0.1:18080 https_proxy=http://127.0.0.1:18080 \
    NO_PROXY=localhost,127.0.0.1 no_proxy=localhost,127.0.0.1 \
    dbus-run-session -- "$APP" --no-sandbox --disable-dev-shm-usage --disable-gpu \
    --ozone-platform=x11 --remote-debugging-port=9334 \
    --proxy-server=http://127.0.0.1:18080 --proxy-bypass-list="127.0.0.1;localhost" \
    --user-data-dir="$BASE/userdata" \
    >"$BASE/logs/trae.log" 2>&1 </dev/null &
fi

# 4) 等待 CDP 就绪
for i in $(seq 1 60); do
  if curl -s --noproxy '*' --max-time 2 http://127.0.0.1:9334/json/version >/dev/null; then
    echo "[ok] Trae CDP ready (9334) after ${i}s"
    exit 0
  fi
  sleep 1
done
echo "[fail] Trae CDP not ready; see $BASE/logs/trae.log"
tail -5 "$BASE/logs/trae.log"
exit 1
