// Trae 每日签到探测/领取（通过 CDP 操作已登录的 Trae CN 客户端）
// 用法: node /workspace/.trae-auto/tools/claim.js
const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.connectOverCDP('http://127.0.0.1:9334');
  const page = browser.contexts().flatMap(c => c.pages()).find(p => p.url().includes('solo'));
  if (!page) { console.log('NO_PAGE'); process.exit(3); }

  const text = await page.evaluate(() => document.body.innerText || '');
  const loggedIn = !/\bLog in\b/.test(text) && !/^\s*登录\s*$/m.test(text);
  if (!loggedIn) {
    console.log('NOT_LOGGED_IN');
    await page.screenshot({ path: '/workspace/.trae-auto/logs/state.png' });
    process.exit(2);
  }

  await page.screenshot({ path: '/workspace/.trae-auto/logs/state.png' });
  // 尝试点击签到/领取入口（UI 版本可能变化，失败时保留截图人工确认）
  const candidates = ['签到', '每日签到', '领取', '领取积分', '立即领取'];
  let clicked = null;
  for (const c of candidates) {
    const el = page.getByText(c, { exact: false }).first();
    if (await el.count() > 0) {
      try { await el.click({ timeout: 3000 }); clicked = c; break; } catch (e) {}
    }
  }
  await page.waitForTimeout(2500);
  await page.screenshot({ path: '/workspace/.trae-auto/logs/checkin.png' });
  const after = await page.evaluate(() => document.body.innerText || '');
  console.log(JSON.stringify({
    clicked,
    hasPointsKeyword: /积分|points/i.test(after),
    snippet: after.slice(0, 300)
  }));
  process.exit(0);
})().catch(e => { console.error('ERR', e.message); process.exit(1); });
