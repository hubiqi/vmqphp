#!/bin/bash
# 每日签到入口（供定时任务调用）：拉起环境 -> 执行签到 -> 写日志
set -u
BASE=/workspace/.trae-auto
DAY=$(date +%Y%m%d-%H%M)
LOG="$BASE/logs/checkin-$DAY.log"
{
  echo "== $DAY =="
  bash "$BASE/start_app.sh" || { echo "START_FAIL"; exit 1; }
  node "$BASE/tools/claim.js"
  echo "EXIT=$?"
} 2>&1 | tee "$LOG"
